
<link rel="shortcut icon" href="<?php echo e(asset('img/codot-logo.png')); ?>">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/css/app.css">

<!-- Notyf -->
<link type="text/css" href="<?php echo e(url('assets/vendor/notyf/notyf.min.css')); ?>" rel="stylesheet">

<!-- Volt CSS -->
<link type="text/css" href="<?php echo e(url('assets/css/volt.css')); ?>" rel="stylesheet">
<?php /**PATH /var/www/cod-ot/resources/views/layouts/partials/head.blade.php ENDPATH**/ ?>