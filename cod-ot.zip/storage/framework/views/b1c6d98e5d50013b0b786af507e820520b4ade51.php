    
    <?php $__env->startSection('title'); ?><?php echo e($seo['title']); ?><?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('canonical'); ?><?php echo e($seo['canonical']); ?><?php $__env->stopSection(); ?>



    <?php $__env->startSection('content'); ?>

        <div id="app">
            <app></app>
        </div>


        <script>
            var context = <?php echo json_encode($context); ?>

        </script>

        <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.global', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/cod-ot/resources/views/home/app.blade.php ENDPATH**/ ?>