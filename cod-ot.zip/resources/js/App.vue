<template>
    <main>
        <div class="container py-4">
            <router-view></router-view>
        </div>
    </main>
</template>
