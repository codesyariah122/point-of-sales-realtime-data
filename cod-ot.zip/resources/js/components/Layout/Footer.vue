<template>
    <footer class="pt-3 mt-4 text-muted border-top">&copy; 2021</footer>
</template>
