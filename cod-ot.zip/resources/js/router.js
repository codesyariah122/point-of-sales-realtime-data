import Home from "./views/Home";

export const routes = [
    {
        name: "home",
        path: "/",
        component: Home,
    },
];
