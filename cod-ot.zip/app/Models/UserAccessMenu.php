<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAccessMenu extends Model
{
    protected $table = 'menu_sub_menu';

    use HasFactory;
}
